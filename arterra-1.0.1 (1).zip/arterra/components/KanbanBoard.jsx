/* @yb-template KanbanBoard v4 id – from the YeshBe component library. This copy is the app's own: change it freely. */
function KanbanBoard({
  collection,
  statusField = "status",
  columns = [],
  titleField = "title",
  subtitleField,
  metaField,
  badgeField,
  variant = "classic",
  imageField = null,
  tagsField = null,
  assigneeField = null,
  dueField = null,
  progressField = null,
  laneField = null,
  amountField = null,
  probabilityField = null,
  idField = null,
  countsField = null,
  lanes,
  wipLimits = null,
  showCounts = true,
  collapsible = false,
  admin = false,
  filter,
  onCardClick,
  onAdd,
  labels = {},
  limit = 200,
}) {
  const L = Object.assign({
    /* ★ id – this copy's own words; labels={{ … }} still overrides any of them */
    empty: "Tidak ada apa pun di sini",
    add: "Tambah",
    loading: "Memuat…",
    error: "Tidak dapat memuat papan",
    move: "Pindahkan ke",
    total: "Total",
    weighted: "Tertimbang",
    overLimit: "Melebihi batas",
    due: "Tenggat",
    overdue: "Lewat jatuh tempo",
    collapse: "Ciutkan",
    expand: "Bentangkan",
    noLane: "Tanpa grup",
    progress: "Progres",
    probability: "Probabilitas",
    comments: "Komentar",
    attachments: "Lampiran",
  }, labels && typeof labels === "object" ? labels : {});

  const VARIANTS = ["classic", "compact", "rich", "swimlanes", "pipeline", "minimal", "glass", "colorful", "timeline", "dark"];
  const V = VARIANTS.includes(variant) ? variant : "classic";
  const rtl = typeof dir !== "undefined" && dir === "rtl";
  const loc = typeof appLocale === "function" ? appLocale() : undefined;
  const mm = (q) => typeof window !== "undefined" && !!window.matchMedia && window.matchMedia(q).matches;
  /* a phone / tablet has no drag & drop – every card gets a "Move to" picker there */
  const touch = mm("(pointer: coarse)");

  /* ---------- safe readers: record fields can be missing, null, the wrong type or an object ---------- */
  const lang = typeof activeLang === "string" ? activeLang : "";
  const text = (v) => {
    if (v == null) return "";
    if (typeof v === "string") return v;
    if (typeof v === "number") return isFinite(v) ? String(v) : "";
    if (typeof v === "boolean") return String(v);
    if (Array.isArray(v)) return v.map(text).filter(Boolean).join(", ");
    if (v instanceof Date) return isNaN(v.getTime()) ? "" : v.toLocaleDateString();
    if (typeof v === "object") {
      const pick = v.name ?? v.title ?? v.label ?? (lang ? v[lang] : undefined) ?? v.en;
      if (pick != null && typeof pick !== "object") return text(pick);
      const s = Object.values(v).find((x) => typeof x === "string");
      return s || "";
    }
    return "";
  };
  const num = (v) => {
    if (typeof v === "number") return isFinite(v) ? v : null;
    if (typeof v === "string") {
      const s = v.replace(/[\s,](?=\d{3}(\D|$))/g, "").replace(/[^\d.\-]/g, "");
      const n = parseFloat(s);
      return isFinite(n) ? n : null;
    }
    if (v && typeof v === "object" && !Array.isArray(v)) return num(v.value ?? v.amount ?? null);
    return null;
  };
  const arr = (v) => {
    if (Array.isArray(v)) return v.filter((x) => x != null && x !== "");
    if (typeof v === "string") return v.split(/[,;|]/).map((s) => s.trim()).filter(Boolean);
    return v == null || v === "" ? [] : [v];
  };
  const date = (v) => {
    if (v == null || v === "" || typeof v === "boolean") return null;
    const d = v instanceof Date ? v : typeof v === "number" || typeof v === "string" ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d : null;
  };
  const url = (v) => {
    if (Array.isArray(v)) return url(v[0]);
    if (v && typeof v === "object") return url(v.url ?? v.src);
    if (typeof v !== "string") return "";
    const s = v.trim();
    return /^(https?:\/\/|\/|data:image\/)/i.test(s) ? s : "";
  };
  const pct = (v) => {
    let n = num(v);
    if (n == null) return null;
    if (n > 0 && n < 1) n = n * 100;
    return Math.round(Math.max(0, Math.min(100, n)));
  };
  const cssColor = (c) => (typeof c === "string" && c.length < 64 && /^[#a-z0-9(),.%\s\-]+$/i.test(c) ? c : null);
  const mix = (c, p, base) => "color-mix(in srgb, " + c + " " + p + "%, " + (base || "var(--surface)") + ")";
  const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
  const initials = (s) => (String(s).trim().split(/[\s@._-]+/).filter(Boolean).slice(0, 2).map((w) => Array.from(w)[0] || "").join("") || "?").toUpperCase();
  const money = (n) => {
    try { if (typeof fmt !== "undefined" && fmt && typeof fmt.currency === "function") return fmt.currency(n); } catch (e) {}
    try { return new Intl.NumberFormat(loc).format(n); } catch (e) { return String(n); }
  };
  const fmtDate = (d) => {
    try {
      const other = d.getFullYear() !== new Date().getFullYear();
      return d.toLocaleDateString(loc, other ? { day: "numeric", month: "short", year: "numeric" } : { day: "numeric", month: "short" });
    } catch (e) { return d.toISOString().slice(0, 10); }
  };
  const WARN = "var(--warning, var(--accent, var(--primary)))";

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [dragId, setDragId] = useState(null);
  const [overCol, setOverCol] = useState(null);
  const [collapsed, setCollapsed] = useState({});
  const [closedLanes, setClosedLanes] = useState({});
  const [wide, setWide] = useState(() => mm("(min-width: 768px)"));
  const [themeDark, setThemeDark] = useState(false);
  const probeRef = useRef(null);

  const api = admin
    ? { all: (o) => sdk.adminGetAll(collection, o), update: (id, d) => sdk.adminUpdate(collection, id, d) }
    : { all: (o) => sdk.getAll(collection, o), update: (id, d) => sdk.update(collection, id, d) };

  const statusOf = (r) => text(r[statusField]);
  const cols = (Array.isArray(columns) && columns.length
    ? columns.map((c) => {
        if (c == null) return null;
        if (typeof c !== "object") return { value: c, label: text(c) };
        const value = c.value ?? c.id ?? c.label;
        if (value == null || typeof value === "object") return null;
        return { value, label: text(c.label ?? value), color: cssColor(c.color), emoji: typeof c.emoji === "string" ? c.emoji : typeof c.icon === "string" && c.icon.length <= 4 ? c.icon : "", probability: pct(c.probability) };
      }).filter(Boolean)
    : Array.from(new Set(rows.map(statusOf).filter(Boolean))).map((v) => ({ value: v, label: v }))
  ).map((c) => ({ color: null, emoji: "", probability: null, ...c }));

  let palette = [];
  try { if (typeof chartColors === "function") palette = arr(chartColors(Math.max(cols.length, 6))).filter((x) => cssColor(x)); } catch (e) {}
  if (!palette.length) palette = ["var(--primary)", "var(--accent, var(--primary))", "var(--success, var(--primary))", WARN, "var(--error, var(--primary))", "var(--text-muted)"];
  const colColor = (col, i) => col.color || palette[i % palette.length];
  const tone = (s) => palette[hash(String(s)) % palette.length];

  async function load() {
    setLoading(true); setError("");
    try {
      const res = await api.all({ limit });
      let list = (res && Array.isArray(res.data) ? res.data : []).filter((r) => r && typeof r === "object" && !Array.isArray(r));
      if (typeof filter === "function") list = list.filter(filter);
      setRows(list);
    } catch (e) { setError((e && typeof e.message === "string" && e.message) || L.error); }
    finally { setLoading(false); }
  }
  useEffect(() => { if (collection) load(); }, [collection]);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const q = window.matchMedia("(min-width: 768px)");
    const on = () => setWide(!!q.matches);
    on();
    if (q.addEventListener) { q.addEventListener("change", on); return () => q.removeEventListener("change", on); }
    if (q.addListener) { q.addListener(on); return () => q.removeListener(on); }
  }, []);

  /* the "dark" design stays deep on a light theme (text colour as the surface) and on a dark theme (its own background) */
  useEffect(() => {
    if (V !== "dark" || !probeRef.current || typeof getComputedStyle !== "function") return;
    try {
      const lum = (c) => {
        const s = String(c || "");
        const n = (s.match(/-?[\d.]+/g) || []).map(Number);
        if (!n.length) return null;
        if (/^(ok)?l(ab|ch)/i.test(s)) return n[0];
        if (n.length < 3) return null;
        return 0.2126 * n[0] + 0.7152 * n[1] + 0.0722 * n[2];
      };
      const cs = getComputedStyle(probeRef.current);
      const bg = lum(cs.backgroundColor), fg = lum(cs.color);
      if (bg != null && fg != null) setThemeDark(bg < fg);
    } catch (e) {}
  }, [V, loading]);

  async function moveTo(id, value) {
    const row = rows.find((r) => r.id === id);
    if (!row || statusOf(row) === String(value)) return;
    const before = rows;
    setRows(rows.map((r) => (r.id === id ? { ...r, [statusField]: value } : r)));
    try { await api.update(id, { [statusField]: value }); }
    catch (e) { setRows(before); toast.error((e && typeof e.message === "string" && e.message) || L.error); }
  }

  if (loading) return <div className="grid gap-4 md:grid-cols-3">{[0, 1, 2].map((i) => <Skeleton key={i} h={220} r={16} />)}</div>;
  if (error) return <div className="rounded-xl border border-border bg-surface p-6 text-text-secondary">{error}</div>;

  /* ---------- per-record pieces ---------- */
  const titleOf = (r) => text(r[titleField]) || "#" + text(r.id);
  const subOf = (r) => (subtitleField ? text(r[subtitleField]) : "");
  const metaOf = (r) => (metaField ? text(r[metaField]) : "");
  const badgeOf = (r) => (badgeField ? text(r[badgeField]) : "");
  const idOf = (r) => { const s = idField ? text(r[idField]).trim() : ""; return s && /^\d+$/.test(s) ? "#" + s : s; };
  const peopleOf = (r) => (assigneeField ? arr(r[assigneeField]).map((x) => text(x).trim()).filter(Boolean) : []);
  const tagsOf = (r) => (tagsField ? arr(r[tagsField]).map((x) => text(x).trim()).filter(Boolean) : []);
  const imageOf = (r) => (imageField ? url(r[imageField]) : "");
  const dueOf = (r) => (dueField ? date(r[dueField]) : null);
  const progressOf = (r) => (progressField ? pct(r[progressField]) : null);
  const amountOf = (r) => (amountField ? num(r[amountField]) : null);
  const countsOf = (r) => {
    if (!countsField) return { c: null, a: null };
    const v = r[countsField];
    if (Array.isArray(v)) return { c: v.length || null, a: null };
    if (v && typeof v === "object") return { c: num(v.comments ?? v.comment ?? v.messages ?? null), a: num(v.attachments ?? v.files ?? null) };
    return { c: num(v), a: null };
  };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  /* the last column counts as "done" – a finished card is never shown as overdue */
  const isOverdue = (d, ci) => !!d && d < today && !(cols.length > 1 && ci === cols.length - 1);
  const emojiSplit = (s) => {
    try {
      const m = s.match(/^(\p{Extended_Pictographic}️?(‍\p{Extended_Pictographic}️?)*)\s*/u);
      return m && m[0].length < s.length ? [m[1], s.slice(m[0].length)] : ["", s];
    } catch (e) { return ["", s]; }
  };
  const colIndex = {};
  cols.forEach((c, i) => { colIndex[String(c.value)] = i; });
  const inCol = (col) => rows.filter((r) => statusOf(r) === String(col.value));

  const wipOf = (col) => {
    if (!wipLimits || typeof wipLimits !== "object") return null;
    const n = num(wipLimits[col.value] ?? wipLimits[col.label] ?? null);
    return n != null && n >= 0 ? n : null;
  };
  const isOverWip = (col, n) => { const l = wipOf(col); return l != null && n > l; };

  /* ---------- interaction ---------- */
  const cardBind = (r, ci) => ({
    draggable: !touch,
    onDragStart: (e) => { setDragId(r.id); try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", String(r.id)); } catch (x) {} },
    onDragEnd: () => { setDragId(null); setOverCol(null); },
    onClick: () => onCardClick && onCardClick(r),
    onKeyDown: (e) => {
      if (e.target !== e.currentTarget) return;
      if ((e.key === "Enter" || e.key === " ") && onCardClick) { e.preventDefault(); onCardClick(r); return; }
      if (e.altKey && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
        e.preventDefault();
        const fwd = (e.key === "ArrowRight") !== rtl;
        const t = cols[ci + (fwd ? 1 : -1)];
        if (t) moveTo(r.id, t.value);
      }
    },
    tabIndex: 0,
    role: onCardClick ? "button" : undefined,
  });
  const dropBind = (value, key) => {
    const k = key ?? String(value);
    return {
      onDragOver: (e) => { e.preventDefault(); if (overCol !== k) setOverCol(k); },
      onDragLeave: (e) => { if (e.currentTarget.contains && e.relatedTarget && e.currentTarget.contains(e.relatedTarget)) return; setOverCol((v) => (v === k ? null : v)); },
      onDrop: (e) => { e.preventDefault(); setOverCol(null); if (dragId != null) moveTo(dragId, value); setDragId(null); },
    };
  };
  const dragging = (r) => (dragId === r.id ? " opacity-50" : "");
  const focusRing = " outline-none focus-visible:ring-2 focus-visible:ring-primary";
  const grab = touch ? "" : " cursor-grab active:cursor-grabbing";
  const mover = (r, cls, style) =>
    touch && cols.length > 1 ? (
      <select value="" onClick={(e) => e.stopPropagation()} onChange={(e) => e.target.value && moveTo(r.id, cols.find((c) => String(c.value) === e.target.value)?.value ?? e.target.value)}
              aria-label={L.move} style={style}
              className={cls || "mt-2 h-9 w-full rounded-lg border border-border bg-surface-2 px-2 text-xs text-text-secondary"}>
        <option value="">{L.move}…</option>
        {cols.filter((c) => String(c.value) !== statusOf(r)).map((c) => <option key={String(c.value)} value={String(c.value)}>{c.label}</option>)}
      </select>
    ) : null;
  const canCollapse = collapsible && wide && V !== "swimlanes";
  const toggleCol = (col) => setCollapsed((m) => ({ ...m, [String(col.value)]: !m[String(col.value)] }));
  /* a header is a button when columns can collapse */
  const header = (col, cls, style, content) =>
    canCollapse ? (
      <button type="button" onClick={() => toggleCol(col)} aria-label={L.collapse + ": " + col.label} title={L.collapse} aria-expanded="true"
              className={cls + " w-full cursor-pointer text-start" + focusRing} style={style}>{content}</button>
    ) : <div className={cls} style={style}>{content}</div>;

  /* count pill – "n", "n / limit" with WIP limits, warning colour when over */
  const counter = (col, n, cls, style) => {
    const lim = wipOf(col);
    const over = lim != null && n > lim;
    if (!showCounts && !over) return null;
    return (
      <span className={cls + " inline-flex shrink-0 items-center gap-1 tabular-nums"} style={over ? { ...(style || {}), color: WARN, background: mix(WARN, 14, "transparent") } : style}
            title={over ? L.overLimit : undefined}>
        {over && <AlertCircle size={12} />}
        {showCounts ? (lim != null ? n + " / " + lim : n) : L.overLimit}
        {over && showCounts && <span className="sr-only">{L.overLimit}</span>}
      </span>
    );
  };
  const overHead = (over) => (over ? { boxShadow: "inset 0 -2px 0 " + WARN } : undefined);

  /* small shared visuals */
  const avatars = (names, size, ringStyle) =>
    names.length ? (
      <span className="flex shrink-0 items-center">
        {names.slice(0, 3).map((n, k) => (
          <span key={k} title={n} className={"inline-flex items-center justify-center rounded-full font-semibold " + (size || "h-6 w-6 text-[10px]") + (k ? " -ms-1.5" : "")}
                style={{ background: mix(tone(n), 24), color: mix(tone(n), 70, "var(--text)"), boxShadow: "0 0 0 2px " + (ringStyle || "var(--surface)") }}>{initials(n)}</span>
        ))}
        {names.length > 3 && <span className={"-ms-1.5 inline-flex items-center justify-center rounded-full bg-surface-2 font-medium text-text-muted " + (size || "h-6 w-6 text-[10px]")} style={{ boxShadow: "0 0 0 2px " + (ringStyle || "var(--surface)") }}>+{names.length - 3}</span>}
      </span>
    ) : null;
  const tagChips = (tags, max, cls) =>
    tags.length ? (
      <div className={"flex flex-wrap gap-1 " + (cls || "")}>
        {tags.slice(0, max).map((t, k) => (
          <span key={k} className="max-w-full truncate rounded-md px-1.5 py-0.5 text-[11px] font-medium" style={{ background: mix(tone(t), 16), color: mix(tone(t), 72, "var(--text)") }}>{t}</span>
        ))}
        {tags.length > max && <span className="rounded-md bg-surface-2 px-1.5 py-0.5 text-[11px] text-text-muted">+{tags.length - max}</span>}
      </div>
    ) : null;
  const dueChip = (d, ci, cls) =>
    d ? (
      <span className={"inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-medium tabular-nums " + (isOverdue(d, ci) ? "bg-error-light text-error-text" : "bg-surface-2 text-text-secondary") + " " + (cls || "")}
            title={isOverdue(d, ci) ? L.overdue : L.due}>
        <Clock size={11} />{fmtDate(d)}<span className="sr-only">{isOverdue(d, ci) ? " " + L.overdue : ""}</span>
      </span>
    ) : null;
  const countIcons = (r, cls) => {
    const { c, a } = countsOf(r);
    if (c == null && a == null) return null;
    return (
      <span className={"inline-flex items-center gap-2 text-[11px] tabular-nums " + (cls || "text-text-muted")}>
        {c != null && <span className="inline-flex items-center gap-0.5" title={L.comments}><MessageCircle size={12} />{c}</span>}
        {a != null && <span className="inline-flex items-center gap-0.5" title={L.attachments}><Paperclip size={12} />{a}</span>}
      </span>
    );
  };
  const bar = (p, cls, fill) =>
    p == null ? null : (
      <div className={"h-1.5 overflow-hidden rounded-full bg-surface-2 " + (cls || "")} role="progressbar" aria-valuenow={p} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full" style={{ width: p + "%", background: fill || "var(--primary)" }} />
      </div>
    );

  /* ---------- whole-board empty state ---------- */
  if (!cols.length) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border bg-surface px-6 py-14 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-2 text-text-muted"><Inbox size={22} /></span>
        <div className="text-sm text-text-secondary">{L.empty}</div>
      </div>
    );
  }

  /* ================= cards, one anatomy per design ================= */
  const card = (r, col, ci) => {
    const c = colColor(col, ci);
    const b = cardBind(r, ci);
    const title = titleOf(r), sub = subOf(r), meta = metaOf(r), badge = badgeOf(r), rid = idOf(r);
    const due = dueOf(r), od = isOverdue(due, ci);

    if (V === "compact") {
      const ppl = peopleOf(r);
      return (
        <div key={r.id} {...b} className={"group flex items-center gap-2 rounded-md bg-surface px-2 text-xs transition-colors hover:bg-background" + grab + focusRing + dragging(r) + (touch ? " min-h-[44px] flex-wrap py-1.5" : " h-8")}>
          {rid && <span className="shrink-0 font-mono text-[10px] text-text-muted">{rid}</span>}
          <span className="min-w-0 flex-1 truncate font-medium text-text">{title}</span>
          {meta && <span className="max-w-[35%] shrink-0 truncate text-[11px] text-text-muted">{meta}</span>}
          {badge && <span className="shrink-0 rounded bg-surface-2 px-1.5 py-px text-[10px] font-medium text-text-secondary">{badge}</span>}
          {due && <span className={"shrink-0 text-[10px] tabular-nums " + (od ? "font-semibold text-error" : "text-text-muted")} title={od ? L.overdue : L.due}>{fmtDate(due)}</span>}
          {ppl.length > 0 && avatars(ppl.slice(0, 1), "h-5 w-5 text-[9px]")}
          {mover(r, "h-9 w-full basis-full rounded-md border border-border bg-surface-2 px-2 text-[11px] text-text-secondary")}
        </div>
      );
    }

    if (V === "rich") {
      const img = imageOf(r), tags = tagsOf(r), ppl = peopleOf(r), p = progressOf(r);
      const counts = countIcons(r);
      return (
        <div key={r.id} {...b} className={"overflow-hidden rounded-2xl border border-border bg-surface shadow-sm transition duration-200 hover:shadow-lg motion-safe:hover:-translate-y-0.5" + grab + focusRing + dragging(r)}>
          {img && (
            <div className="aspect-[16/9] overflow-hidden bg-surface-2">
              <img src={img} alt="" loading="lazy" draggable={false} className="h-full w-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
            </div>
          )}
          <div className="p-3.5">
            {tagChips(tags, 3, "mb-2")}
            <div className="text-[15px] font-semibold leading-snug text-text">{title}</div>
            {sub && <div className="mt-1 line-clamp-2 text-[13px] leading-relaxed text-text-secondary">{sub}</div>}
            {p != null && (
              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between text-[11px] text-text-muted"><span>{L.progress}</span><span className="tabular-nums">{p}%</span></div>
                {bar(p, "", p >= 100 ? "var(--success, var(--primary))" : undefined)}
              </div>
            )}
            {(ppl.length > 0 || due || counts || badge || meta) && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {avatars(ppl)}
                {dueChip(due, ci)}
                {meta && <span className="truncate text-[11px] text-text-muted">{meta}</span>}
                <span className="flex-1" />
                {counts}
                {badge && <StatusBadge value={badge} />}
              </div>
            )}
            {mover(r)}
          </div>
        </div>
      );
    }

    if (V === "pipeline") {
      const amt = amountOf(r);
      const prob = probabilityField ? pct(r[probabilityField]) : null;
      const ppl = peopleOf(r);
      return (
        <div key={r.id} {...b} className={"rounded-xl border border-border bg-surface p-3 shadow-sm transition hover:shadow-md motion-safe:hover:-translate-y-px" + grab + focusRing + dragging(r)}>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="truncate text-sm font-medium text-text">{title}</div>
              {sub && <div className="mt-0.5 truncate text-xs text-text-secondary">{sub}</div>}
            </div>
            {avatars(ppl.slice(0, 2), "h-6 w-6 text-[10px]")}
          </div>
          {amt != null && <div className="mt-2 text-lg font-semibold tabular-nums tracking-tight text-text">{money(amt)}</div>}
          {prob != null && (
            <div className="mt-2 flex items-center gap-2" title={L.probability}>
              <div className="h-1 flex-1 overflow-hidden rounded-full bg-surface-2">
                <div className="h-full rounded-full" style={{ width: prob + "%", background: prob >= 70 ? "var(--success, var(--primary))" : "var(--primary)" }} />
              </div>
              <span className="text-[11px] tabular-nums text-text-muted">{prob}%</span>
            </div>
          )}
          {(meta || badge || due) && (
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
              {meta ? <span className="truncate text-xs text-text-muted">{meta}</span> : <span />}
              <span className="flex items-center gap-1.5">{dueChip(due, ci)}{badge && <StatusBadge value={badge} />}</span>
            </div>
          )}
          {mover(r)}
        </div>
      );
    }

    if (V === "minimal") {
      return (
        <div key={r.id} {...b} className={"rounded-e-lg border-s-2 py-2.5 pe-2 ps-3.5 transition-colors hover:bg-surface-2" + grab + focusRing + dragging(r)} style={{ borderInlineStartColor: c }}>
          <div className="text-[15px] leading-snug text-text">{title}</div>
          {sub && <div className="mt-1 line-clamp-2 text-[13px] leading-relaxed text-text-muted">{sub}</div>}
          {(meta || badge || due) && (
            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-text-muted">
              {meta && <span>{meta}</span>}
              {badge && <span>{badge}</span>}
              {due && <span className={od ? "text-error" : ""} title={od ? L.overdue : L.due}>{fmtDate(due)}</span>}
            </div>
          )}
          {mover(r, "mt-2 h-9 w-full rounded-lg border border-border bg-background px-2 text-xs text-text-secondary")}
        </div>
      );
    }

    if (V === "glass") {
      const ppl = peopleOf(r);
      return (
        <div key={r.id} {...b} className={"rounded-2xl border p-3.5 transition duration-300 motion-safe:hover:-translate-y-0.5" + grab + focusRing + dragging(r)}
             style={{ background: mix("var(--surface)", 78, "transparent"), borderColor: mix("var(--surface)", 85, "transparent"),
                      boxShadow: "0 12px 32px -16px " + mix("var(--text)", 45, "transparent") + ", inset 0 1px 0 " + mix("var(--surface)", 80, "transparent") }}>
          <div className="text-sm font-semibold text-text">{title}</div>
          {sub && <div className="mt-1 line-clamp-2 text-xs leading-relaxed text-text-secondary">{sub}</div>}
          {(meta || badge || due || ppl.length > 0) && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {avatars(ppl, "h-6 w-6 text-[10px]")}
              {meta && <span className="truncate text-xs text-text-muted">{meta}</span>}
              <span className="flex-1" />
              {dueChip(due, ci)}
              {badge && <StatusBadge value={badge} />}
            </div>
          )}
          {mover(r, "mt-2 h-9 w-full rounded-xl border border-border bg-surface px-2 text-xs text-text-secondary")}
        </div>
      );
    }

    if (V === "colorful") {
      const [emo, rest] = emojiSplit(title);
      const ppl = peopleOf(r), tags = tagsOf(r);
      return (
        <div key={r.id} {...b} className={"rounded-[1.25rem] border-2 bg-surface p-3.5 transition duration-200 motion-safe:hover:-translate-y-0.5 motion-safe:hover:-rotate-1" + grab + focusRing + dragging(r)}
             style={{ borderColor: mix(c, 24, "transparent"), boxShadow: "0 4px 0 " + mix(c, 30, "transparent") }}>
          <div className="flex items-start gap-2.5">
            {emo && <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl text-xl" style={{ background: mix(c, 16) }} aria-hidden="true">{emo}</span>}
            <div className="min-w-0 flex-1">
              <div className="text-[15px] font-bold leading-snug text-text">{rest}</div>
              {sub && <div className="mt-1 line-clamp-2 text-[13px] text-text-secondary">{sub}</div>}
            </div>
          </div>
          {tagChips(tags, 4, "mt-2.5")}
          {(meta || badge || due || ppl.length > 0) && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {avatars(ppl, "h-7 w-7 text-[11px]")}
              {meta && <span className="truncate text-xs font-medium" style={{ color: mix(c, 60, "var(--text)") }}>{meta}</span>}
              <span className="flex-1" />
              {dueChip(due, ci, "rounded-full px-2")}
              {badge && <StatusBadge value={badge} />}
            </div>
          )}
          {mover(r, "mt-2.5 h-10 w-full rounded-full border-2 bg-surface px-3 text-xs font-medium text-text-secondary", { borderColor: mix(c, 24, "transparent") })}
        </div>
      );
    }

    if (V === "timeline") {
      const p = progressOf(r), ppl = peopleOf(r);
      return (
        <div key={r.id} {...b} className={"relative rounded-xl border border-border bg-surface p-3 shadow-sm transition-colors hover:border-primary" + grab + focusRing + dragging(r)}>
          <span aria-hidden="true" className="absolute -start-[22px] top-4 h-2.5 w-2.5 rotate-45 rounded-[2px] border-2 bg-surface" style={{ borderColor: c }} />
          {due && (
            <div className={"mb-1 flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wider " + (od ? "text-error" : "text-primary")} title={od ? L.overdue : L.due}>
              <Calendar size={11} />{fmtDate(due)}
            </div>
          )}
          <div className="text-sm font-semibold leading-snug text-text">{title}</div>
          {sub && <div className="mt-1 line-clamp-2 text-xs text-text-secondary">{sub}</div>}
          {p != null && <div className="mt-2.5 flex items-center gap-2">{bar(p, "flex-1", c)}<span className="text-[11px] tabular-nums text-text-muted">{p}%</span></div>}
          {(meta || badge || ppl.length > 0) && (
            <div className="mt-2.5 flex items-center justify-between gap-2">
              {meta ? <span className="truncate text-xs text-text-muted">{meta}</span> : <span />}
              <span className="flex items-center gap-1.5">{avatars(ppl, "h-5 w-5 text-[9px]")}{badge && <StatusBadge value={badge} />}</span>
            </div>
          )}
          {mover(r)}
        </div>
      );
    }

    if (V === "dark") {
      const ppl = peopleOf(r), tags = tagsOf(r);
      const frac = cols.length > 1 ? ci / (cols.length - 1) : 1;
      const chip = "rounded border px-1.5 py-px text-[11px]";
      const chipStyle = { borderColor: "var(--kb-line)", color: "var(--kb-muted)" };
      return (
        <div key={r.id} {...b} className={"rounded-lg border px-3 py-2.5 transition-colors hover:bg-[var(--kb-hover)] outline-none focus-visible:ring-2 focus-visible:ring-primary" + grab + dragging(r)}
             style={{ background: "var(--kb-card)", borderColor: "var(--kb-line)" }}>
          {(rid || ppl.length > 0) && (
            <div className="mb-1 flex items-center gap-2 text-[11px]" style={{ color: "var(--kb-muted)" }}>
              {rid && <span className="font-mono tracking-tight">{rid}</span>}
              <span className="flex-1" />
              {avatars(ppl.slice(0, 2), "h-5 w-5 text-[9px]", "var(--kb-card)")}
            </div>
          )}
          <div className="flex items-start gap-2">
            <span aria-hidden="true" className="mt-[3px] h-3 w-3 shrink-0 rounded-full border-[1.5px]"
                  style={{ borderColor: c, background: "conic-gradient(" + c + " " + Math.round(frac * 360) + "deg, transparent 0)", boxShadow: "inset 0 0 0 1.5px var(--kb-card)" }} />
            <span className="text-[13px] font-medium leading-snug" style={{ color: "var(--kb-fg)" }}>{title}</span>
          </div>
          {sub && <div className="mt-1 line-clamp-2 ps-5 text-xs" style={{ color: "var(--kb-muted)" }}>{sub}</div>}
          {(badge || meta || due || tags.length > 0) && (
            <div className="mt-2 flex flex-wrap items-center gap-1.5 ps-5">
              {badge && <span className={chip} style={chipStyle}>{badge}</span>}
              {tags.slice(0, 3).map((t, k) => (
                <span key={k} className={chip + " inline-flex items-center gap-1"} style={chipStyle}><span className="h-1.5 w-1.5 rounded-full" style={{ background: tone(t) }} />{t}</span>
              ))}
              {due && <span className={chip + " font-mono"} style={od ? { borderColor: "var(--error)", color: "var(--error)" } : chipStyle} title={od ? L.overdue : L.due}>{fmtDate(due)}</span>}
              {meta && <span className="truncate text-[11px]" style={{ color: "var(--kb-dim)" }}>{meta}</span>}
            </div>
          )}
          {mover(r, "mt-2 h-9 w-full rounded-md border px-2 text-xs", { background: "var(--kb-col)", borderColor: "var(--kb-line)", color: "var(--kb-fg)" })}
        </div>
      );
    }

    /* classic (and swimlane cells use a tighter version below) */
    return (
      <div key={r.id} {...b}
           className={(touch ? "" : "cursor-grab active:cursor-grabbing ") + "rounded-xl border border-border bg-surface p-3 shadow-sm transition hover:shadow-md" + focusRing + dragging(r)}>
        <div className="text-sm font-medium text-text">{title}</div>
        {sub && <div className="mt-1 line-clamp-2 text-xs text-text-secondary">{sub}</div>}
        {(metaField || badgeField) && (
          <div className="mt-2 flex items-center justify-between gap-2">
            {metaField ? <span className="text-xs text-text-muted">{meta}</span> : <span />}
            {badge && <StatusBadge value={badge} />}
          </div>
        )}
        {mover(r)}
      </div>
    );
  };

  /* ================= swimlanes: lanes × columns ================= */
  if (V === "swimlanes") {
    const laneOf = (r) => (laneField ? text(r[laneField]).trim() : "");
    const found = Array.from(new Set(rows.map(laneOf)));
    const order = Array.isArray(lanes) ? lanes.map((x) => text(x).trim()).filter(Boolean) : [];
    const laneKeys = order.filter((k) => found.includes(k))
      .concat(found.filter((k) => k && !order.includes(k)).sort((a, b) => a.localeCompare(b, loc)))
      .concat(found.includes("") || !found.length ? [""] : []);
    const colHeads = cols.map((col, ci) => ({ col, ci, n: inCol(col).length }));
    const swimCard = (r, col, ci) => {
      const b = cardBind(r, ci), rid = idOf(r), sub = subOf(r), meta = metaOf(r), badge = badgeOf(r), due = dueOf(r);
      return (
        <div key={r.id} {...b} className={"rounded-lg border border-border bg-surface p-2.5 shadow-sm transition hover:shadow-md" + grab + focusRing + dragging(r)}>
          {rid && <div className="mb-0.5 font-mono text-[10px] text-text-muted">{rid}</div>}
          <div className="text-[13px] font-medium leading-snug text-text">{titleOf(r)}</div>
          {sub && <div className="mt-0.5 truncate text-xs text-text-secondary">{sub}</div>}
          {(meta || badge || due) && (
            <div className="mt-2 flex flex-wrap items-center justify-between gap-1.5">
              {meta ? <span className="truncate text-[11px] text-text-muted">{meta}</span> : <span />}
              <span className="flex items-center gap-1.5">{dueChip(due, ci)}{badge && <StatusBadge value={badge} />}</span>
            </div>
          )}
          {mover(r)}
        </div>
      );
    };
    return (
      <div className="md:overflow-x-auto md:pb-2">
        <div className="md:min-w-max">
          <div className="mb-2 hidden gap-3 ps-[13px] pe-[13px] md:flex">
            {colHeads.map(({ col, ci, n }) => (
              <div key={String(col.value)} className="flex w-64 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface-2 px-3 py-2" style={overHead(isOverWip(col, n))}>
                <span className="h-2 w-2 rounded-full" style={{ background: colColor(col, ci) }} />
                <span className="truncate text-sm font-semibold text-text">{col.label}</span>
                <span className="flex-1" />
                {counter(col, n, "rounded-full bg-surface px-2 py-0.5 text-xs text-text-muted")}
              </div>
            ))}
          </div>
          {laneKeys.map((lk) => {
            const lr = rows.filter((r) => laneOf(r) === lk);
            const open = !closedLanes[lk];
            const label = lk || L.noLane;
            return (
              <section key={lk || "__none"} className="mb-3 rounded-2xl border border-border bg-surface">
                <button type="button" aria-expanded={open} onClick={() => setClosedLanes((m) => ({ ...m, [lk]: !m[lk] }))}
                        title={open ? L.collapse : L.expand}
                        className={"flex min-h-[44px] w-full items-center gap-2.5 rounded-2xl px-3 py-2 text-start transition-colors hover:bg-surface-2" + focusRing}>
                  <ChevronDown size={16} className={"shrink-0 text-text-muted transition-transform " + (open ? "" : rtl ? "rotate-90" : "-rotate-90")} />
                  {laneField && lk && <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold" style={{ background: mix(tone(lk), 22), color: mix(tone(lk), 70, "var(--text)") }}>{initials(lk)}</span>}
                  <span className="truncate text-sm font-semibold text-text">{label}</span>
                  {showCounts && <span className="shrink-0 text-xs tabular-nums text-text-muted">{lr.length}</span>}
                  <span className="flex-1" />
                  {lr.length > 0 && (
                    <span className="hidden h-1.5 w-28 shrink-0 overflow-hidden rounded-full bg-surface-2 sm:flex" aria-hidden="true">
                      {cols.map((col, ci) => {
                        const n = lr.filter((r) => statusOf(r) === String(col.value)).length;
                        return n ? <span key={String(col.value)} style={{ width: (n / lr.length) * 100 + "%", background: colColor(col, ci) }} /> : null;
                      })}
                    </span>
                  )}
                </button>
                {open && (
                  <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto px-3 pb-3 md:snap-none md:overflow-visible">
                    {cols.map((col, ci) => {
                      const items = lr.filter((r) => statusOf(r) === String(col.value));
                      const key = lk + "\u0001" + String(col.value);
                      const isOver = overCol === key;
                      return (
                        <div key={String(col.value)} {...dropBind(col.value, key)}
                             className={"flex w-[78vw] max-w-[17rem] shrink-0 snap-start flex-col gap-2 rounded-xl p-2 transition-colors md:w-64 md:max-w-none " + (isOver ? "bg-primary-light ring-1 ring-primary" : "bg-surface-2")}>
                          <div className="flex items-center gap-1.5 px-1 text-[11px] font-medium text-text-muted md:hidden">
                            <span className="h-1.5 w-1.5 rounded-full" style={{ background: colColor(col, ci) }} />{col.label}
                            {showCounts && <span className="tabular-nums">· {items.length}</span>}
                          </div>
                          {items.map((r) => swimCard(r, col, ci))}
                          {!items.length && <div className="min-h-[44px] rounded-lg border border-dashed border-border" aria-label={L.empty} />}
                          {onAdd && (
                            <button type="button" onClick={() => onAdd(col.value, lk || null)} aria-label={L.add + ": " + col.label}
                                    className={"flex min-h-[36px] items-center justify-center gap-1 rounded-lg text-xs text-text-muted transition hover:bg-surface hover:text-text" + focusRing}>
                              <Plus size={13} /> {L.add}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      </div>
    );
  }

  /* ================= column designs ================= */
  const n1 = Math.max(cols.length - 1, 1);
  const placed = rows.filter((r) => colIndex[statusOf(r)] != null);
  /* timeline: overall progress = average phase of all cards */
  const reach = placed.length ? placed.reduce((s, r) => s + colIndex[statusOf(r)], 0) / placed.length : -1;

  /* pipeline totals */
  const probOf = (r, col) => (probabilityField ? pct(r[probabilityField]) : null) ?? col.probability;
  const colSums = cols.map((col) => {
    const items = inCol(col);
    let sum = 0, w = 0, hasW = false;
    items.forEach((r) => {
      const a = amountOf(r) || 0;
      sum += a;
      const p = probOf(r, col);
      if (p != null) { hasW = true; w += (a * p) / 100; }
    });
    return { sum, w: hasW ? w : null };
  });
  const grand = colSums.reduce((s, x) => s + x.sum, 0);
  const grandW = colSums.some((x) => x.w != null) ? colSums.reduce((s, x) => s + (x.w || 0), 0) : null;

  const darkVars = (() => {
    const deep = themeDark ? "var(--background, var(--surface))" : "var(--text)";
    const fg = themeDark ? "var(--text)" : "var(--surface)";
    return {
      "--kb-bg": deep, "--kb-col": mix(deep, 95, fg), "--kb-card": mix(deep, 89, fg), "--kb-hover": mix(deep, 84, fg),
      "--kb-line": mix(deep, 82, fg), "--kb-fg": fg, "--kb-muted": mix(fg, 58, deep), "--kb-dim": mix(fg, 40, deep),
      background: "var(--kb-bg)", color: "var(--kb-fg)",
    };
  })();

  const scroller = {
    compact: "-mx-4 flex snap-x snap-mandatory gap-2 overflow-x-auto px-4 pb-2 md:mx-0 md:snap-none md:px-0",
    minimal: "-mx-4 flex snap-x snap-mandatory gap-6 overflow-x-auto px-4 pb-2 md:mx-0 md:snap-none md:gap-10 md:px-0",
    glass: "relative flex snap-x snap-mandatory gap-3 overflow-x-auto pb-1 md:snap-none md:gap-4",
    dark: "flex snap-x snap-mandatory gap-2 overflow-x-auto pb-1 md:snap-none",
    timeline: "-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 pt-1 md:mx-0 md:snap-none md:px-0",
  }[V] || "-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 md:mx-0 md:snap-none md:gap-4 md:px-0";

  const colLook = (col, ci, isOver) => {
    const c = colColor(col, ci);
    switch (V) {
      case "compact": return { cls: "w-[78vw] max-w-[17rem] rounded-lg border p-1.5 md:w-64 " + (isOver ? "border-primary bg-primary-light" : "border-border bg-surface-2") };
      case "rich": return { cls: "w-[86vw] max-w-[21rem] rounded-3xl p-2.5 md:w-80 " + (isOver ? "bg-primary-light ring-2 ring-primary" : "bg-surface-2") };
      case "pipeline": return { cls: "w-[85vw] max-w-[19rem] rounded-2xl border md:w-72 " + (isOver ? "border-primary bg-primary-light" : "border-border bg-surface-2") };
      case "minimal": return { cls: "w-[80vw] max-w-[19rem] rounded-xl px-1 py-2 md:w-72 " + (isOver ? "bg-surface-2" : "") };
      case "glass": return {
        cls: "w-[84vw] max-w-[20rem] rounded-3xl border p-3 backdrop-blur-xl md:w-72",
        style: { background: isOver ? mix("var(--primary)", 20, mix("var(--surface)", 60, "transparent")) : mix("var(--surface)", 50, "transparent"),
                 borderColor: isOver ? "var(--primary)" : mix("var(--surface)", 70, "transparent"), boxShadow: "0 20px 50px -30px " + mix("var(--text)", 50, "transparent") },
      };
      case "colorful": return {
        cls: "w-[84vw] max-w-[20rem] rounded-[1.75rem] p-3 md:w-72",
        style: { background: mix(c, isOver ? 24 : 12), outline: isOver ? "2px dashed " + c : "none", outlineOffset: 2 },
      };
      case "timeline": return { cls: "w-[80vw] max-w-[18rem] md:w-72" };
      case "dark": return { cls: "w-[84vw] max-w-[20rem] rounded-xl border p-2 md:w-72", style: { background: "var(--kb-col)", borderColor: isOver ? "var(--primary)" : "var(--kb-line)" } };
      default: return { cls: "w-[85vw] max-w-[20rem] rounded-2xl border p-3 md:w-72 " + (isOver ? "border-primary bg-primary-light" : "border-border bg-surface-2") };
    }
  };

  const clip = (first) => (rtl
    ? (first ? "polygon(0 0, 100% 0, 100% 100%, 0 100%, 12px 50%)" : "polygon(0 0, 100% 0, calc(100% - 12px) 50%, 100% 100%, 0 100%, 12px 50%)")
    : (first ? "polygon(0 0, calc(100% - 12px) 0, 100% 50%, calc(100% - 12px) 100%, 0 100%)" : "polygon(0 0, calc(100% - 12px) 0, 100% 50%, calc(100% - 12px) 100%, 0 100%, 12px 50%)"));

  const colHeader = (col, ci, n) => {
    const c = colColor(col, ci);
    const over = isOverWip(col, n);
    switch (V) {
      case "compact":
        return header(col, "mb-1 flex items-center gap-1.5 rounded-md px-1.5 py-1", overHead(over), <>
          <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: c }} />
          <span className={"truncate text-[11px] font-semibold uppercase tracking-wider " + (over ? "text-warning" : "text-text-secondary")}>{col.label}</span>
          {counter(col, n, "text-[11px] text-text-muted rounded px-1")}
        </>);
      case "rich":
        return header(col, "mb-2.5 flex items-center gap-2 rounded-xl px-1.5 py-1", overHead(over), <>
          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: c }} />
          <span className={"truncate text-sm font-semibold " + (over ? "text-warning" : "text-text")}>{col.label}</span>
          <span className="flex-1" />
          {counter(col, n, "rounded-full bg-surface px-2 py-0.5 text-xs font-medium text-text-secondary")}
        </>);
      case "pipeline": {
        const s = colSums[ci];
        return header(col, "block px-3 pt-3", undefined, <>
          <div className="flex h-8 items-center gap-2 ps-4 pe-5 text-xs font-semibold" style={{ clipPath: clip(ci === 0), background: over ? mix(WARN, 22) : mix(c, 20), color: over ? WARN : mix(c, 62, "var(--text)") }}>
            <span className="truncate">{col.label}</span>
            <span className="flex-1" />
            {counter(col, n, "rounded-full px-1.5 text-[11px]")}
          </div>
          {amountField && (
            <div className="mt-3 px-1">
              <div className="text-xl font-semibold tabular-nums tracking-tight text-text">{money(s.sum)}</div>
              {s.w != null && <div className="mt-0.5 text-xs tabular-nums text-text-muted">{L.weighted} {money(Math.round(s.w))}</div>}
            </div>
          )}
        </>);
      }
      case "minimal":
        return header(col, "mb-4 flex items-baseline gap-2 border-b border-border px-1 pb-3", over ? { borderColor: WARN } : undefined, <>
          <span className={"truncate text-sm font-medium " + (over ? "text-warning" : "text-text")}>{col.label}</span>
          {counter(col, n, "rounded px-1 text-sm font-normal text-text-muted")}
        </>);
      case "glass":
        return header(col, "mb-3 flex items-center gap-2 rounded-xl px-1.5 py-1", overHead(over), <>
          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: c, boxShadow: "0 0 0 4px " + mix(c, 25, "transparent") }} />
          <span className={"truncate text-sm font-semibold " + (over ? "text-warning" : "text-text")}>{col.label}</span>
          <span className="flex-1" />
          {counter(col, n, "rounded-full px-2 py-0.5 text-xs font-medium text-text-secondary", { background: mix("var(--surface)", 70, "transparent") })}
        </>);
      case "colorful":
        return header(col, "mb-3 flex items-center gap-2.5 rounded-2xl px-1 py-1", overHead(over), <>
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl text-lg" style={{ background: mix(c, 30) }} aria-hidden="true">
            {col.emoji || <span className="h-3 w-3 rounded-full" style={{ background: c }} />}
          </span>
          <span className="truncate text-base font-extrabold tracking-tight" style={{ color: over ? WARN : mix(c, 62, "var(--text)") }}>{col.label}</span>
          <span className="flex-1" />
          {counter(col, n, "rounded-full px-2.5 py-0.5 text-xs font-bold", { background: mix(c, 26), color: mix(c, 70, "var(--text)") })}
        </>);
      case "timeline": {
        const fill = Math.max(0, Math.min(1, reach - ci));
        const done = reach >= ci + 1 || (ci === cols.length - 1 && reach >= ci && placed.length > 0);
        const current = !done && reach >= ci;
        return (
          <div className="mb-4">
            <div className="flex items-center">
              <span className={"relative z-[1] flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-[11px] font-bold tabular-nums " +
                               (done ? "border-primary bg-primary text-primary-text" : current ? "border-primary bg-surface text-primary" : "border-border bg-surface text-text-muted")}>
                {done ? <Check size={14} /> : String(ci + 1).padStart(2, "0")}
              </span>
              {ci < cols.length - 1 ? (
                <span className="relative -me-3 h-0.5 flex-1 overflow-hidden bg-border" aria-hidden="true">
                  <span className="absolute inset-0 bg-primary transition-transform duration-700 motion-reduce:transition-none" style={{ transform: "scaleX(" + fill + ")", transformOrigin: rtl ? "right" : "left" }} />
                </span>
              ) : <span className="flex-1" />}
            </div>
            {header(col, "mt-3 flex items-center gap-2 rounded-lg px-0.5 py-0.5", overHead(over), <>
              <span className={"truncate text-sm font-semibold " + (over ? "text-warning" : "text-text")}>{col.label}</span>
              {counter(col, n, "rounded-full bg-surface-2 px-2 py-0.5 text-xs text-text-muted")}
            </>)}
          </div>
        );
      }
      case "dark": {
        const frac = cols.length > 1 ? ci / n1 : 1;
        return header(col, "mb-2 flex items-center gap-2 rounded-md px-1.5 py-1", overHead(over), <>
          <span aria-hidden="true" className="h-3 w-3 shrink-0 rounded-full border-[1.5px]"
                style={{ borderColor: c, background: "conic-gradient(" + c + " " + Math.round(frac * 360) + "deg, transparent 0)", boxShadow: "inset 0 0 0 1.5px var(--kb-col)" }} />
          <span className="truncate text-[13px] font-medium" style={{ color: over ? WARN : "var(--kb-fg)" }}>{col.label}</span>
          {counter(col, n, "rounded px-1 font-mono text-xs", { color: "var(--kb-muted)" })}
        </>);
      }
      default:
        return header(col, "mb-3 flex items-center justify-between rounded-lg px-1", overHead(over), <>
          <span className={"text-sm font-semibold " + (over ? "text-warning" : "text-text")}>{col.label}</span>
          {counter(col, n, "rounded-full bg-surface px-2 py-0.5 text-xs text-text-muted")}
        </>);
    }
  };

  const emptyCol = (col, ci) => {
    const c = colColor(col, ci);
    switch (V) {
      case "compact": return <div className="px-2 py-3 text-[11px] text-text-muted">{L.empty}</div>;
      case "minimal": return <div className="px-3.5 py-6 text-sm text-text-muted">{L.empty}</div>;
      case "glass": return <div className="rounded-2xl border border-dashed p-5 text-center text-xs text-text-secondary" style={{ borderColor: mix("var(--text)", 18, "transparent") }}>{L.empty}</div>;
      case "colorful": return <div className="rounded-[1.25rem] border-2 border-dashed p-5 text-center text-sm font-medium" style={{ borderColor: mix(c, 35, "transparent"), color: mix(c, 60, "var(--text)") }}>{L.empty}</div>;
      case "dark": return <div className="rounded-lg border border-dashed p-4 text-center text-xs" style={{ borderColor: "var(--kb-line)", color: "var(--kb-dim)" }}>{L.empty}</div>;
      case "timeline": return <div className="py-4 text-xs text-text-muted">{L.empty}</div>;
      default: return <div className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-text-muted">{L.empty}</div>;
    }
  };

  const addBtn = (col, ci) => {
    if (!onAdd) return null;
    const c = colColor(col, ci);
    const go = () => onAdd(col.value);
    const lbl = L.add + ": " + col.label;
    switch (V) {
      case "compact": return <button type="button" onClick={go} aria-label={lbl} className={"mt-1 flex h-8 items-center gap-1 rounded-md px-2 text-xs text-text-muted transition hover:bg-surface hover:text-text" + focusRing}><Plus size={13} /> {L.add}</button>;
      case "minimal": return <button type="button" onClick={go} aria-label={lbl} className={"mt-2 flex min-h-[40px] items-center gap-1.5 px-3.5 text-sm text-text-muted transition-colors hover:text-text" + focusRing}><Plus size={14} /> {L.add}</button>;
      case "colorful": return <button type="button" onClick={go} aria-label={lbl} className={"mt-3 flex min-h-[44px] items-center justify-center gap-1 rounded-full text-sm font-bold transition motion-safe:hover:scale-[1.02]" + focusRing} style={{ background: mix(c, 20), color: mix(c, 68, "var(--text)") }}><Plus size={16} /> {L.add}</button>;
      case "glass": return <button type="button" onClick={go} aria-label={lbl} className={"mt-3 flex min-h-[40px] items-center justify-center gap-1 rounded-2xl text-sm text-text-secondary transition hover:text-text" + focusRing} style={{ background: mix("var(--surface)", 40, "transparent") }}><Plus size={15} /> {L.add}</button>;
      case "dark": return <button type="button" onClick={go} aria-label={lbl} className="mt-1 flex min-h-[36px] items-center gap-1.5 rounded-md px-2 text-xs transition-colors hover:bg-[var(--kb-hover)] outline-none focus-visible:ring-2 focus-visible:ring-primary" style={{ color: "var(--kb-muted)" }}><Plus size={13} /> {L.add}</button>;
      case "pipeline": return <button type="button" onClick={go} aria-label={lbl} className={"mx-2.5 mb-2.5 flex min-h-[40px] items-center justify-center gap-1 rounded-xl border border-dashed border-border text-sm text-text-secondary transition hover:bg-surface hover:text-text" + focusRing}><Plus size={15} /> {L.add}</button>;
      case "timeline": return <button type="button" onClick={go} aria-label={lbl} className={"ms-[15px] mt-1 flex min-h-[40px] items-center gap-1 ps-4 text-sm text-text-muted transition hover:text-primary" + focusRing}><Plus size={14} /> {L.add}</button>;
      default:
        return (
          <button type="button" onClick={go}
                  className="mt-3 flex items-center justify-center gap-1 rounded-xl py-2 text-sm text-text-secondary transition hover:bg-surface hover:text-text">
            <Plus size={15} /> {L.add}
          </button>
        );
    }
  };

  const bodyCls = {
    compact: "flex min-h-[48px] flex-col gap-px overflow-hidden rounded-md",
    rich: "flex min-h-[80px] flex-col gap-2.5",
    pipeline: "flex min-h-[80px] flex-col gap-2 p-2.5",
    minimal: "flex min-h-[80px] flex-col gap-1.5",
    glass: "flex min-h-[80px] flex-col gap-2.5",
    colorful: "flex min-h-[80px] flex-col gap-3",
    timeline: "ms-[15px] flex min-h-[80px] flex-col gap-3 border-s-2 border-dashed border-border ps-4",
    dark: "flex min-h-[60px] flex-col gap-1.5",
  }[V] || "flex min-h-[80px] flex-col gap-2";

  const collapsedBar = (col, ci, n) => {
    const k = String(col.value);
    const isOver = overCol === k;
    const c = colColor(col, ci);
    const look = V === "dark" ? { background: "var(--kb-col)", borderColor: isOver ? "var(--primary)" : "var(--kb-line)", color: "var(--kb-fg)" }
      : V === "glass" ? { background: mix("var(--surface)", 50, "transparent"), borderColor: mix("var(--surface)", 70, "transparent") }
      : V === "colorful" ? { background: mix(c, 14), borderColor: "transparent" }
      : undefined;
    return (
      <button key={k} type="button" {...dropBind(col.value)} onClick={() => toggleCol(col)} aria-label={L.expand + ": " + col.label} title={L.expand} aria-expanded="false"
              className={"flex w-11 shrink-0 flex-col items-center gap-3 self-stretch rounded-2xl border py-3 text-text transition-colors" + focusRing +
                         (V === "glass" ? " backdrop-blur-xl" : "") + (look ? "" : isOver ? " border-primary bg-primary-light" : " border-border bg-surface-2")}
              style={look}>
        <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: c }} />
        <span className="text-xs font-semibold" style={{ writingMode: "vertical-rl" }}>{col.label}</span>
        {counter(col, n, "text-[11px] opacity-70 rounded px-0.5")}
      </button>
    );
  };

  const board = (
    <div className={scroller}>
      {cols.map((col, ci) => {
        const items = inCol(col);
        const k = String(col.value);
        if (canCollapse && collapsed[k]) return collapsedBar(col, ci, items.length);
        const isOver = overCol === k;
        const look = colLook(col, ci, isOver);
        return (
          <div key={k} {...dropBind(col.value)}
               className={"flex shrink-0 snap-start flex-col transition-colors " + look.cls} style={look.style}>
            {colHeader(col, ci, items.length)}
            <div className={bodyCls + (V === "timeline" && isOver ? " rounded-e-xl bg-primary-light" : "")}>
              {items.map((r) => card(r, col, ci))}
              {!items.length && emptyCol(col, ci)}
            </div>
            {addBtn(col, ci)}
          </div>
        );
      })}
    </div>
  );

  if (V === "glass") {
    const bgc = "var(--background, var(--surface))";
    return (
      <div className="relative isolate -mx-4 overflow-hidden px-4 py-4 md:mx-0 md:rounded-[2rem] md:p-5">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10"
             style={{ background: "radial-gradient(60% 70% at 10% 0%, " + mix("var(--primary)", 45, "transparent") + ", transparent 70%), radial-gradient(55% 65% at 95% 100%, " + mix("var(--accent, var(--primary))", 45, "transparent") + ", transparent 70%), linear-gradient(135deg, " + mix("var(--primary)", 16, bgc) + ", " + mix("var(--accent, var(--primary))", 16, bgc) + ")" }} />
        {board}
      </div>
    );
  }

  if (V === "dark") {
    return (
      <div className="-mx-4 px-3 py-3 md:mx-0 md:rounded-2xl md:p-4" style={darkVars}>
        <span ref={probeRef} aria-hidden="true" className="hidden bg-surface text-text" />
        {board}
      </div>
    );
  }

  if (V === "pipeline" && amountField) {
    return (
      <div>
        <div className="mb-4 flex flex-wrap items-end gap-x-8 gap-y-3">
          <div>
            <div className="text-xs font-medium uppercase tracking-wider text-text-muted">{L.total}</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-semibold tabular-nums tracking-tight text-text">{money(grand)}</span>
              {showCounts && <span className="rounded-full bg-surface-2 px-2 py-0.5 text-xs tabular-nums text-text-muted">{placed.length}</span>}
            </div>
          </div>
          {grandW != null && (
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-text-muted">{L.weighted}</div>
              <div className="mt-1 text-2xl font-semibold tabular-nums tracking-tight text-primary">{money(Math.round(grandW))}</div>
            </div>
          )}
        </div>
        {board}
      </div>
    );
  }

  if (V === "timeline" && placed.length) {
    const pc = Math.round((Math.max(reach, 0) / n1) * 100);
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs text-text-muted">
          <span className="font-medium uppercase tracking-wider">{L.progress}</span>
          <span className="tabular-nums font-semibold text-text">{cols.length > 1 ? pc : 100}%</span>
        </div>
        {board}
      </div>
    );
  }

  return board;
}

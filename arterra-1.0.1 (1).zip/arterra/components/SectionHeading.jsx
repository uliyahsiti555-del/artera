/* SectionHeading – eyebrow + title + subtitle with an optional action on the end side: { eyebrow, title, subtitle, action (a React node, e.g. a button), size = "md" ("lg" for page titles) } */
function SectionHeading({ eyebrow, title, subtitle, action, size = "md" }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0 text-start">
        {eyebrow && (
          <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-accent">
            <span className="h-px w-6 bg-gradient-to-r from-accent to-primary" />
            {eyebrow}
          </div>
        )}
        {title && (
          <h2 className={`font-semibold tracking-tight text-text ${size === "lg" ? "text-[32px] leading-tight" : "text-[24px] leading-tight"}`}>
            {title}
          </h2>
        )}
        {subtitle && <p className="mt-1.5 max-w-2xl text-[14px] leading-relaxed text-text-secondary">{subtitle}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

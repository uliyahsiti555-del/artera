/* EmptyState – geometric placeholder for an empty list or canvas: { icon (a lucide component, default Hexagon), title, text, action (a React node, e.g. a button) } */
function EmptyState({ icon: Icon = Hexagon, title, text, action }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <div className="relative mb-6 flex h-28 w-28 items-center justify-center">
        <div className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(circle, rgba(34,211,238,0.18), transparent 70%)" }} />
        <motion.div className="absolute inset-2 rounded-[28px] border border-accent/40" animate={{ rotate: 360 }} transition={{ duration: 18, repeat: Infinity, ease: "linear" }} />
        <motion.div className="absolute inset-5 rotate-45 rounded-[20px] border border-primary/50" animate={{ rotate: -315 }} transition={{ duration: 24, repeat: Infinity, ease: "linear" }} />
        <Icon className="relative h-7 w-7 text-accent" strokeWidth={1.5} />
      </div>
      {title && <h3 className="text-[18px] font-semibold tracking-tight text-text">{title}</h3>}
      {text && <p className="mt-2 max-w-sm text-[14px] leading-relaxed text-text-secondary">{text}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

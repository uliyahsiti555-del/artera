/* GlassPanel – frosted glass panel with the cyan→violet "holo-edge" sweep on hover/active: { children, onClick, active = false, solid = false, delay = 0, className = "" } – put padding (e.g. "p-6") and grid spans in className */
function GlassPanel({ children, onClick, active = false, solid = false, delay = 0, className = "" }) {
  const click = onClick ? {
    role: "button", tabIndex: 0, onClick,
    onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(e); } },
  } : {};
  const mask = { WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", maskComposite: "exclude" };
  return (
    <motion.div {...click} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay }} whileHover={{ y: -2 }}
      className={`group relative rounded-[16px] border border-white/10 text-text transition-shadow duration-300 hover:shadow-[0_0_28px_rgba(34,211,238,0.14)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent ${onClick ? "cursor-pointer" : ""} ${className}`}
      style={{ background: solid ? "var(--surface-2)" : "color-mix(in srgb, var(--surface-2) 55%, transparent)", backdropFilter: "blur(16px)" }}>
      <div className="pointer-events-none absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-white/25 to-transparent" />
      {children}
      <div style={mask} className={`pointer-events-none absolute inset-0 overflow-hidden rounded-[16px] p-px transition-opacity duration-300 ${active ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}>
        <motion.div className="absolute -inset-1/2" animate={{ rotate: 360 }} transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          style={{ background: "conic-gradient(from 0deg, transparent 0%, var(--accent) 20%, var(--primary) 40%, transparent 60%)" }} />
      </div>
    </motion.div>
  );
}

function AppShell({ children, isLoggedIn, user, navigateTo, onLogout, currentPage,
                    activeLang, langs, switchLang, dir, schema }) {
  const t = {
    root: "relative min-h-screen bg-background text-text",
    side: "group fixed inset-y-0 start-0 z-40 hidden w-[72px] flex-col border-e border-white/10 backdrop-blur-xl md:flex lg:w-[260px]",
    brand: "flex h-16 shrink-0 items-center justify-center gap-3 px-4 transition lg:justify-start lg:px-6",
    wordmark: "hidden font-heading text-[17px] font-semibold tracking-[0.28em] text-text lg:inline",
    tagline: "hidden px-6 pb-4 text-[11px] leading-snug text-text-muted lg:block",
    nav: "flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-2",
    itemBase: "group relative flex min-h-12 items-center justify-center gap-3 rounded-xl px-3 text-[14px] font-medium transition-all duration-200 lg:justify-start",
    itemOn: "bg-gradient-to-r from-accent/15 to-primary/10 text-text",
    itemOff: "text-text-secondary hover:bg-white/5 hover:text-text",
    bar: "absolute start-0 top-2 bottom-2 w-[3px] rounded-e-full bg-accent shadow-[0_0_12px_var(--accent)]",
    cta: "group relative flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-primary-hover to-primary px-3 text-[14px] font-semibold text-white shadow-[0_0_24px_rgba(99,102,241,0.35)] transition hover:shadow-[0_0_30px_rgba(34,211,238,0.35)]",
    userCard: "group relative mt-3 flex items-center justify-center gap-3 rounded-xl border border-white/10 bg-white/5 p-2 lg:justify-start lg:p-3",
    avatar: "flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-primary to-accent font-heading font-semibold text-white",
    top: "sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/10 px-4 backdrop-blur-xl md:px-8",
    eyebrow: "text-[10px] font-semibold uppercase tracking-[0.2em] text-accent",
    title: "truncate font-heading text-[18px] font-semibold leading-tight tracking-tight text-text md:text-[22px]",
    search: "flex h-10 w-full items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 transition focus-within:border-accent/60 focus-within:shadow-[0_0_16px_rgba(34,211,238,0.15)] md:w-72",
    searchInput: "w-full bg-transparent text-[14px] text-text outline-none placeholder:text-text-muted",
    iconBtn: "flex h-10 w-10 items-center justify-center rounded-xl text-text-secondary transition hover:bg-white/5 hover:text-text",
    menu: "absolute end-0 top-full z-50 mt-2 w-64 rounded-xl border border-menu-border bg-menu-bg p-2 shadow-shadow-lg",
    menuItem: "flex min-h-11 w-full items-center gap-3 rounded-lg px-3 text-[14px] text-text transition hover:bg-menu-item-hover",
    lang: "rounded-lg px-2 py-1 text-[11px] font-semibold uppercase tracking-wider transition",
    langOn: "bg-white/10 text-accent",
    langOff: "text-text-muted hover:text-text",
    main: "relative z-10 md:ms-[72px] lg:ms-[260px]",
    content: "p-4 pb-28 md:p-8 md:pb-8",
    tabbar: "fixed inset-x-0 bottom-0 z-40 flex border-t border-white/10 px-2 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden",
    tab: "relative flex h-14 flex-1 items-center justify-center transition",
    tabOn: "text-accent",
    tabOff: "text-text-muted hover:text-text",
    fab: "fixed bottom-[76px] end-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary-hover to-primary text-white shadow-[0_0_28px_rgba(99,102,241,0.55)] transition active:scale-95 md:hidden"
  };

  const [menuOpen, setMenuOpen] = useState(false);
  const [q, setQ] = useState("");
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setMenuOpen(false); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [menuOpen]);

  useEffect(() => {
    const url = schema && schema.icon;
    if (!url || typeof document === "undefined") return;
    const ensure = (selector, create) => {
      let el = document.querySelector(selector);
      if (!el) { el = create(); document.head.appendChild(el); }
      return el;
    };
    const icon = ensure("link[rel~='icon']", () => { const l = document.createElement("link"); l.rel = "icon"; return l; });
    icon.href = url;
    const touch = ensure("link[rel='apple-touch-icon']", () => { const l = document.createElement("link"); l.rel = "apple-touch-icon"; return l; });
    touch.href = url;
    const og = ensure("meta[property='og:image']", () => { const m = document.createElement("meta"); m.setAttribute("property", "og:image"); return m; });
    og.setAttribute("content", url);
  }, [schema && schema.icon]);

  if (!isLoggedIn) return <>{children}</>;

  const items = navigation(schema.pages, activeLang).filter(i => !i.auth || isLoggedIn);
  const home = items.find(i => i.home) || items[0];
  const current = items.find(i => i.name === currentPage);
  const hasProjects = items.some(i => i.name === "ProjectFlow");
  const goHome = () => { if (home) navigateTo(home.name); };

  const icons = {
    Dashboard: typeof LayoutDashboard !== "undefined" ? LayoutDashboard : Hexagon,
    ProjectFlow: typeof Layers !== "undefined" ? Layers : Hexagon,
    IdeaSpace: typeof Lightbulb !== "undefined" ? Lightbulb : Hexagon,
    ColorLab: typeof Palette !== "undefined" ? Palette : Hexagon,
    CharacterForge: typeof Users !== "undefined" ? Users : Hexagon
  };

  const createProject = () => {
    setMenuOpen(false);
    if (hasProjects) navigateTo("ProjectFlow", undefined, undefined, { create: "1" });
  };
  const submitSearch = (e) => {
    e.preventDefault();
    if (hasProjects) navigateTo("ProjectFlow", undefined, undefined, { q: q.trim() });
  };

  const mask = { WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", maskComposite: "exclude" };
  const edge = (on) => (
    <div style={mask} className={"pointer-events-none absolute inset-0 overflow-hidden rounded-[inherit] p-px transition-opacity duration-300 " + (on ? "opacity-100" : "opacity-0 group-hover:opacity-100")}>
      <motion.div className="absolute -inset-1/2" animate={{ rotate: 360 }} transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
        style={{ background: "conic-gradient(from 0deg, transparent 0%, var(--accent) 20%, var(--primary) 40%, transparent 60%)" }} />
    </div>
  );

  const initial = (user && user.name ? user.name.trim().charAt(0) : "?").toUpperCase();
  const avatar = (size) => (
    <span className={t.avatar + " " + size}>
      {user && user.avatar_url ? <img src={user.avatar_url} alt={user.name || ""} className="h-full w-full object-cover" /> : initial}
    </span>
  );

  const logo = (
    <>
      {schema && schema.icon
        ? <img src={schema.icon} alt={schema.title} className="h-9 w-9 shrink-0 rounded-[10px] object-contain drop-shadow-[0_0_10px_var(--accent)]" />
        : <Hexagon size={28} strokeWidth={1.5} className="text-accent drop-shadow-[0_0_8px_var(--accent)]" />}
      <span className={t.wordmark}>{schema ? schema.title : ""}</span>
    </>
  );

  return (
    <div dir={dir} className={t.root}>
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: "linear-gradient(color-mix(in srgb, var(--accent) 4%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--accent) 4%, transparent) 1px, transparent 1px), radial-gradient(60% 40% at 80% 0%, color-mix(in srgb, var(--primary) 14%, transparent), transparent), radial-gradient(40% 30% at 0% 100%, color-mix(in srgb, var(--accent) 8%, transparent), transparent)",
          backgroundSize: "40px 40px, 40px 40px, 100% 100%, 100% 100%",
          WebkitMaskImage: "linear-gradient(to bottom, #000 30%, transparent 100%)",
          maskImage: "linear-gradient(to bottom, #000 30%, transparent 100%)"
        }} />

      <aside className={t.side} style={{ background: "color-mix(in srgb, var(--sidebar-bg) 82%, transparent)" }}>
        <button onClick={goHome} className={t.brand} aria-label={schema ? schema.title : ""}>{logo}</button>
        <p className={t.tagline}>Creative Space Beyond Imagination</p>
        <nav className={t.nav} aria-label="Navigasi utama">
          {items.map(item => {
            const Icon = icons[item.name] || Hexagon;
            const active = item.name === currentPage;
            return (
              <button key={item.name} onClick={() => navigateTo(item.name)} title={item.label}
                aria-current={active ? "page" : undefined}
                className={t.itemBase + " " + (active ? t.itemOn : t.itemOff)}>
                {active && <span className={t.bar} />}
                <Icon size={20} strokeWidth={1.5} className={active ? "text-accent" : "transition group-hover:text-accent"} />
                <span className="hidden truncate lg:inline">{item.label}</span>
                {active && edge(true)}
              </button>
            );
          })}
        </nav>
        <div className="shrink-0 border-t border-white/10 p-3">
          {hasProjects && (
            <button onClick={createProject} className={t.cta} title="Buat Proyek">
              <Plus size={18} strokeWidth={2} />
              <span className="hidden lg:inline">Buat Proyek</span>
              {edge(false)}
            </button>
          )}
          <div className={t.userCard + " flex-col lg:flex-row"}>
            {avatar("h-9 w-9 text-[14px]")}
            <div className="hidden min-w-0 flex-1 text-start lg:block">
              <div className="truncate text-[13px] font-medium text-text">{user ? user.name : ""}</div>
              <div className="truncate text-[11px] text-text-muted">{user ? user.email : ""}</div>
            </div>
            <button onClick={onLogout} aria-label="Keluar" title="Keluar" className={t.iconBtn + " h-9 w-9"}>
              <LogOut size={18} strokeWidth={1.5} />
            </button>
            {edge(false)}
          </div>
        </div>
      </aside>

      <div className={t.main}>
        <header className={t.top} style={{ background: "color-mix(in srgb, var(--background) 72%, transparent)" }}>
          <button onClick={goHome} className="flex shrink-0 items-center md:hidden" aria-label={schema ? schema.title : ""}>
            {schema && schema.icon
              ? <img src={schema.icon} alt={schema.title} className="h-9 w-9 rounded-[10px] object-contain drop-shadow-[0_0_8px_var(--accent)]" />
              : <Hexagon size={28} strokeWidth={1.5} className="text-accent drop-shadow-[0_0_8px_var(--accent)]" />}
          </button>
          <div className="hidden min-w-0 flex-1 text-start sm:block">
            <div className={t.eyebrow}>{schema ? schema.title : ""}</div>
            <div className={t.title}>{current ? current.label : ""}</div>
          </div>
          <div className="flex-1 sm:hidden" />
          {hasProjects && (
            <form onSubmit={submitSearch} className={t.search + " max-w-[220px] sm:max-w-none"} role="search">
              <Search size={16} strokeWidth={1.5} className="shrink-0 text-text-muted" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari proyek, ide, palet…" aria-label="Cari" className={t.searchInput} />
            </form>
          )}
          {langs && langs.length > 1 && (
            <div className="hidden items-center rounded-xl border border-white/10 p-1 sm:flex">
              {langs.map(l => (
                <button key={l} onClick={() => switchLang(l)} className={t.lang + " " + (l === activeLang ? t.langOn : t.langOff)}>{l}</button>
              ))}
            </div>
          )}
          <div className="relative" ref={menuRef}>
            <button onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu akun" aria-expanded={menuOpen}
              className="flex h-10 items-center gap-2 rounded-xl p-1 transition hover:bg-white/5">
              {avatar("h-8 w-8 text-[13px]")}
              <ChevronDown size={14} className={"hidden text-text-muted transition sm:block " + (menuOpen ? "rotate-180" : "")} />
            </button>
            <AnimatePresence>
              {menuOpen && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.15 }} className={t.menu}>
                  <div className="flex items-center gap-3 border-b border-white/10 p-3">
                    {avatar("h-10 w-10 text-[15px]")}
                    <div className="min-w-0 text-start">
                      <div className="truncate text-[14px] font-medium text-text">{user ? user.name : ""}</div>
                      <div className="truncate text-[12px] text-text-muted">{user ? user.email : ""}</div>
                    </div>
                  </div>
                  {langs && langs.length > 1 && (
                    <div className="flex items-center gap-1 p-2 sm:hidden">
                      <Globe size={16} className="text-text-muted" />
                      {langs.map(l => (
                        <button key={l} onClick={() => switchLang(l)} className={t.lang + " " + (l === activeLang ? t.langOn : t.langOff)}>{l}</button>
                      ))}
                    </div>
                  )}
                  <button onClick={() => { setMenuOpen(false); onLogout(); }} className={t.menuItem + " mt-1"}>
                    <LogOut size={18} strokeWidth={1.5} className="text-text-secondary" />
                    Keluar
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </header>

        <main className={t.content}>
          <motion.div key={currentPage} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {children}
          </motion.div>
        </main>
      </div>

      {hasProjects && (
        <button onClick={createProject} aria-label="Buat Proyek" className={t.fab}>
          <Plus size={24} strokeWidth={2} />
        </button>
      )}

      <nav className={t.tabbar} aria-label="Navigasi utama" style={{ background: "color-mix(in srgb, var(--sidebar-bg) 88%, transparent)" }}>
        {items.map(item => {
          const Icon = icons[item.name] || Hexagon;
          const active = item.name === currentPage;
          return (
            <button key={item.name} onClick={() => navigateTo(item.name)} aria-label={item.label}
              aria-current={active ? "page" : undefined} className={t.tab + " " + (active ? t.tabOn : t.tabOff)}>
              {active && <span className="absolute inset-x-4 top-0 h-[2px] rounded-b-full bg-accent shadow-[0_0_12px_var(--accent)]" />}
              <Icon size={22} strokeWidth={1.5} />
              <span className="sr-only">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}